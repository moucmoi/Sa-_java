cd src/Vue
javac --source-path ../Controleur --module-path /usr/share/openjfx/lib/ --add-modules javafx.controls,javafx.fxml *.java
java --module-path /usr/share/openjfx/lib/ --add-modules javafx.controls,javafx.fxml VueAppliJO